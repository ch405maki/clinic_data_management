<template>
    <img src="/images/logo.png" alt="Image Logo">
</template>
